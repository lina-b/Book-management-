package com.example.miniprojet;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class login_acrivity extends AppCompatActivity {
    String email = "linabenhajyahia@gmail.com";
    String password = "1234";
    Intent i = getIntent();


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login_acrivity);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

    }


    public void seconnecter(View v) {

        // Récuperation des paramêtres de connexion saisis par l'utilisateur
        String E = ((EditText) findViewById(R.id.amail)).getText().toString();
        String MP = ((EditText) findViewById(R.id.mp)).getText().toString();
        if (!E.equals(email) || !MP.equals(password))
            Toast.makeText(this, "Email ou mot de passe incorret!", Toast.LENGTH_SHORT).show();
        else {
            Intent I = new Intent(this, MainActivity.class);
            startActivity(I);
        }
    }


    public void modifiermotdepassenew(View v) {
        Intent I = new Intent(this, changement_mdp.class); // changement mot de passe
        I.putExtra("MotDePasse", password);
        startActivityForResult(I, 100);

    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        try {
        if ((requestCode == 100) && (resultCode == Activity.RESULT_OK) ){

            Bundle extra = data.getExtras();
            password = extra.getString("MotDePasse");
            //vider les champs.??????
            Toast.makeText(this, password, Toast.LENGTH_SHORT).show();

        }

        }
        catch (Exception e) {
            Toast.makeText(this, "erreur" + requestCode + resultCode, Toast.LENGTH_SHORT).show();

        }
    }
}