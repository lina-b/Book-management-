package com.example.miniprojet;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
public class changement_mdp extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_changement_mdp);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

    }


    public void enregistrerNouveauPassword(View v)
    {

        Intent i = getIntent() ;

        String MP = i.getStringExtra ( "MotDePasse" );

        String AMP = ((EditText)findViewById(R.id.oldmp)).getText().toString();
        String NMP = ((EditText)findViewById(R.id.newmp)).getText().toString();
        String NMPC = ((EditText)findViewById(R.id.confnewmp)).getText().toString();

        if (!MP.equals(AMP) || !NMP.equals(NMPC))
            Toast.makeText(this, "Mot de passe incorrect!", Toast.LENGTH_SHORT).show();
        else
        {
            Toast.makeText(this, "Nouveau mot de passe enregistré!", Toast.LENGTH_SHORT).show();

            i.putExtra("MotDePasse", NMP);
            setResult(Activity.RESULT_OK, i);


            finish();

        }
    }}